#export JAVA_HOME=/opt/jre/1.8.0_45l
#export OCEAN_WEB_BASE_PORT=9999
#export OCEAN_WEB_LOG_PATH=/opt/pxnet/fxtp/logs